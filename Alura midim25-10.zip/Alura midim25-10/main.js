function tocaSomPom(){
     document.querySelector( '#som_pom').play();
}
function tocaSomClap(){
    document.querySelector( '#som_clap').play();
}
function tocaSomTim(){
    document.querySelector( '#som_tim').play();
}
function tocaSomPuff(){
    document.querySelector( '#som_puff').play();
}
function tocaSomSplash(){
    document.querySelector( '#som_splash').play();
}
function tocaSomToim(){
    document.querySelector( '#som_toim').play();
}
function tocaSomPsh(){
    document.querySelector( '#som_psh').play();
}
function tocaSomTic(){
    document.querySelector( '#som_tic').play();
}
function tocaSomTom(){
    document.querySelector( '#som_tom').play();
}
